﻿/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, onWillStart, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

export class ITManagementDashboard extends Component {
    static template = "it_management.ITManagementDashboard";

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({
            loading: true,
            open: 0,
            high: 0,
            waiting: 0,
            closed: 0,
            total: 0,
            access: 0,
            chats: 0,
            remote: 0,
            trend: [0, 0, 0, 0, 0, 0, 0],
            recent: [],
        });
        onWillStart(() => this.loadDashboard());
    }

    async loadDashboard() {
        const openDomain = [["state", "in", ["new", "progress"]]];
        const highDomain = [["priority", "in", ["2", "3"]], ["state", "not in", ["closed", "cancelled"]]];
        const waitingDomain = [["state", "=", "waiting"]];
        const closedDomain = [["state", "=", "closed"]];
        const [open, high, waiting, closed, total, access, chats, remote, tickets, recent] = await Promise.all([
            this.orm.searchCount("it.ticket", openDomain),
            this.orm.searchCount("it.ticket", highDomain),
            this.orm.searchCount("it.ticket", waitingDomain),
            this.orm.searchCount("it.ticket", closedDomain),
            this.orm.searchCount("it.ticket", []),
            this.orm.searchCount("it.access.request", [["state", "in", ["draft", "submitted", "approved"]]]),
            this.orm.searchCount("it.support.chat", [["state", "=", "open"]]),
            this.orm.searchCount("it.ticket", [["remote_support_requested", "=", true], ["state", "not in", ["closed", "cancelled"]]]),
            this.orm.searchRead("it.ticket", [], ["opened_date"], { limit: 1000 }),
            this.orm.searchRead(
                "it.ticket",
                [],
                ["name", "subject", "employee_id", "priority", "state", "source_ip", "anydesk_id", "opened_date", "verification_status"],
                { limit: 8, order: "id desc" }
            ),
        ]);

        const trend = [0, 0, 0, 0, 0, 0, 0];
        const today = new Date();
        for (const rec of tickets) {
            if (!rec.opened_date) continue;
            const d = new Date(rec.opened_date.replace(" ", "T") + "Z");
            const diff = Math.floor((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) -
                Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())) / 86400000);
            if (diff >= 0 && diff < 7) trend[6 - diff] += 1;
        }

        Object.assign(this.state, { open, high, waiting, closed, total, access, chats, remote, trend, recent, loading: false });
    }

    openAction(xmlId) {
        this.action.doAction(xmlId);
    }

    openTicket(id) {
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "it.ticket",
            res_id: id,
            views: [[false, "form"]],
            target: "current",
        });
    }

    connectAnyDesk(id) {
        if (!id) return;
        const clean = String(id).replace(/[^a-zA-Z0-9]/g, "");
        window.location.href = `anydesk:${clean}`;
    }

    priorityLabel(priority) {
        return { "0": "Low", "1": "Normal", "2": "High", "3": "Critical" }[priority] || "Normal";
    }

    stateLabel(state) {
        return {
            new: "New", progress: "In Progress", waiting: "Awaiting User",
            resolved: "Resolved", closed: "Closed", cancelled: "Cancelled",
        }[state] || state;
    }

    get maxTrend() {
        return Math.max(...this.state.trend, 1);
    }

    get closeRate() {
        return this.state.total ? Math.round((this.state.closed / this.state.total) * 100) : 0;
    }
}

registry.category("actions").add("it_management.dashboard", ITManagementDashboard);

